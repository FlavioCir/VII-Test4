var elencoHTML; 
var erroreHTML;
var elenco = [];

window.addEventListener('DOMContentLoaded', init);

function init() {
    elencoHTML = document.getElementById('dati');
    erroreHTML = document.getElementById('errore');
    printData();
}


function printData() {
    fetch('https://jsonplaceholder.typicode.com/users').then((response) => {
        return response.json();
    }).then((data) => { //con questa tecnica se alla response arriva un errore non ci blocca l'array
        elenco = data;
        if (elenco.length > 0) {
            elenco.map(function (element) {
                let colonna1 = `<td class="fw-bold">${element.id}</td>`;
                let colonna2 = `<td>${element.name}</td>`;
                let colonna3 = `<td>${element.username}</td>`;
                let colonna4 = `<td>${element.email}</td>`;
                let colonna5 = `<td>${element.phone}</td>`;
                elencoHTML.innerHTML += `<tr>${colonna1} ${colonna2} ${colonna3} ${colonna4} ${colonna5}</td>`;
            });
        } else {
            erroreHTML.innerHTML = 'Controllare il link JSON';
        }
    });
}